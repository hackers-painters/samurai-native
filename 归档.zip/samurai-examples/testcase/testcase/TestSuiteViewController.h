//
//  ViewController.h
//  test
//
//  Created by god on 15/4/29.
//  Copyright (c) 2015年 Geek-Zoo Studio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Samurai.h"

@interface TestSuiteViewController : UIViewController

@property (nonatomic, strong) NSString * testSuite;

@end

