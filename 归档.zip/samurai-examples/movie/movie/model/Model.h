//
//  Model.h
//  movie
//
//  Created by QFish on 4/9/15.
//  Copyright (c) 2015 Geek Zoo Studio. All rights reserved.
//

#ifndef movie_Model_h
#define movie_Model_h

#import "Movies.h"
#import "MovieModel.h"
#import "MovieListModel.h"

#endif
